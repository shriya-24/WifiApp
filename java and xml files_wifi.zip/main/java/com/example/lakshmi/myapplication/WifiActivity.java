package com.example.lakshmi.myapplication;
import android.annotation.SuppressLint;
import java.util.*;
import java.math.*;
import android.net.wifi.*;
import java.lang.*;
import java.net.*;
import java.io.*;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.*;
import java.nio.ByteOrder;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.NumberPicker;

import static android.net.wifi.WifiManager.*;

public class WifiActivity extends Activity {
    static PrintWriter out;
    Button enableButton,disableButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //Button viewstring=(Button) findViewById(R.id.button1);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi);
        final TextView textview=(TextView) findViewById(R.id.textView1);

        enableButton=(Button)findViewById(R.id.button1);
        disableButton=(Button)findViewById(R.id.button2);

        final String[] output = {""};
        final String filename = "myfile";

        enableButton.setOnClickListener(new OnClickListener(){
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            public void onClick(View v){

                @SuppressLint("WifiManagerLeak") WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                wifi.setWifiEnabled(true);

                if(wifi.isWifiEnabled()) {
                    WifiInfo wifiInfo = wifi.getConnectionInfo();
                    if(wifiInfo != null) {
                        int dbm = wifiInfo.getRssi();
                        String ssid = wifiInfo.getSSID();
                     /*   int ip = wifiInfo.getIpAddress();
                        String ipaddress = Integer.toString(ip);
                        String mac=wifiInfo.getMacAddress();
                        System.out.println("ip"+ipaddress);
                        System.out.println("mac"+mac);*/
                        int ipAddress = wifi.getConnectionInfo().getIpAddress();

                        // Convert little-endian to big-endianif needed
                        if (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN)) {
                            ipAddress = Integer.reverseBytes(ipAddress);
                        }

                        byte[] ipByteArray = BigInteger.valueOf(ipAddress).toByteArray();

                        String ipAddressString;
                        try {
                            ipAddressString = InetAddress.getByAddress(ipByteArray).getHostAddress();
                        } catch (Exception ex) {
                            Log.e("WIFIIP", "Unable to get host address.");
                            ipAddressString = null;
                        }
                        //System.out.println("ip"+ipAddressString);
                        //System.out.println("info"+wifiInfo.toString());

                        int freq = wifiInfo.getFrequency();
                        int speed = wifiInfo.getLinkSpeed();
                        String bssid = wifiInfo.getBSSID();

                        String dt;
                        Date cal = Calendar.getInstance().getTime();
                        dt = cal.toLocaleString();
                        //System.out.println("date"+dt);
                        String tempoutput;
                        tempoutput = "\n\ndate and time: "+dt +"\nname: " + ssid + "\nbssid: " +bssid + "\nip: " +ipAddressString
                                +"\nspeed: " + speed +" Mbps"+"\nfrequency: " +freq +" Hz"+"\ndbm: " + dbm+" dB";
                        System.out.println("ouput\n"+tempoutput);
                        textview.setText(tempoutput);
                        output[0] = output[0].concat(tempoutput);



                        //String fileContents = "Hello world!";
                        FileOutputStream outputStream;

                        try {
                            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                            outputStream.write(output[0].getBytes());
                            outputStream.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }



                    }
                }
               // String st="Textview String";




            }
        });

        disableButton.setOnClickListener(new OnClickListener(){
            public void onClick(View v){
                @SuppressLint("WifiManagerLeak") WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                wifi.setWifiEnabled(false);
            }
        });
    }
}